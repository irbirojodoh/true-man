import java.util.*;

public class Main {
    public static void main(String[] args) {
        int difficulty = 0, filled = 0, filledIndex, answer;
        Random gacha = new Random();
        System.out.print("Masukan jumlah urinoir:");
        Scanner input = new Scanner(System.in);
        int jumlahUrinoir = input.nextInt();

        urinoir[] bathroom = new urinoir[jumlahUrinoir];

        System.out.print("Masukan tingkat kesulitan: ");
        difficulty = input.nextInt();
        //System.out.println(difficulty);
        generateUrinoir(bathroom, difficulty);
        printUrinoir(bathroom);
        findBuffer(bathroom);
        calculateHeatmap(bathroom);

       System.out.println("Pilih urinoirmu: ");
       answer = input.nextInt();

        System.out.println(checkAnswer(bathroom, answer-1));



    }
    public static void generateUrinoir(urinoir[] bathroom, int difficulty) {
        Random gacha = new Random();
        int total = 0;

        for (int i = 0; i < bathroom.length; i++) {
            bathroom[i] = new urinoir();
            if (total < difficulty)
                bathroom[i].setFilled(gacha.nextBoolean());
            if (bathroom[i].getFilled())
                total++;


        }
    }

    public static void emptyBathroom(urinoir[] bathroom) {
        for (int i = 0; i < bathroom.length; i++) {
            bathroom[i].setFilled(false);
        }
    }

    public static void calculateHeatmap(urinoir[] bathroom) {
        int localBuffer, i, j;
        for (i = 0; i < bathroom.length; i++){
            if (bathroom[i].getBuffer() >= 2)
                localBuffer = 2;
            else
                localBuffer = bathroom[i].getBuffer();
            if(bathroom[i].getFilled() == true){
                bathroom[i].setHeatmap(1000);
            }
            for(j = 1; j <= localBuffer; j++){
                if (bathroom[i-j].getFilled() == true){
                    bathroom[i].setHeatmap(bathroom[i].getHeatmap()+ (3-localBuffer)*(1));
                }
                if (bathroom[i+j].getFilled() == true){
                    bathroom[i].setHeatmap(bathroom[i].getHeatmap()+ (3-localBuffer)*(1));
                }
            }
            //System.out.print(bathroom[i].getHeatmap() + " ");
        }

    }

    public static void findBuffer(urinoir[] bathroom) {
        int i, j;
        for (j = 0; j< bathroom.length; j++) {
            for (i = 0; j-i >= 0 && j+i<= bathroom.length-1 ; i++) {
                // do nothing
            }
            bathroom[j].setBuffer(i-1);
            //System.out.print(bathroom[j].getBuffer() + " ");
        }



    }

    public static void printUrinoir(urinoir[] bathroom) {
        for (int i = 0; i < bathroom.length; i++) {
            if(bathroom[i].getFilled())
                System.out.print("X ");
            else
                System.out.print("O ");
        }
        System.out.println("");
    }

    public static String checkAnswer(urinoir[] bathroom, int answer) {
        if (bathroom[answer].getHeatmap() >= 1000) {
            return "Dah ada orang goblog";
        }
        double min = bathroom[0].getHeatmap();
        int index;

        for(int i = 0; i< bathroom.length; i++){
            if (min > bathroom[i].getHeatmap())
                min = bathroom[i].getHeatmap();
        }
        if (bathroom[answer].getHeatmap() <= min)
            return "Lelaki sejati";

        return "Banci";



    }

}
